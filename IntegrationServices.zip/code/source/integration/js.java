package integration;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.FileOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
// --- <<IS-END-IMPORTS>> ---

public final class js

{
	// ---( internal utility methods )---

	final static js _instance = new js();

	static js _newInstance() { return new js(); }

	static js _cast(Object o) { return (js)o; }

	// ---( server methods )---




	public static final void FormatCustomerCode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(FormatCustomerCode)>> ---
		// @sigtype java 3.5
		// [i] field:0:required customerid
		// [o] field:0:required customercode
		IDataCursor cursor = pipeline.getCursor();
		
		String customerid = null;
		if (cursor.first("customerid")) {
		    customerid = (String) cursor.getValue();
		}
		
		String customercode;
		try {
		    int id = Integer.parseInt(customerid);
		    customercode = String.format("%03d", id); // Misalnya 001, 010, 100
		    // customercode = String.format("%04d", id); // Jika 0001, 0010, 0100
		} catch (Exception e) {
		    customercode = "000"; // Fallback jika error
		}
		
		cursor.insertAfter("customercode", customercode);
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void stringtoLong (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringtoLong)>> ---
		// @sigtype java 3.5
		// [i] field:0:required stringValue
		// [o] field:0:required longValue
		// pipeline input: stringValue (String)
		IDataCursor cursor = pipeline.getCursor();
		String stringValue = IDataUtil.getString(cursor, "stringValue");
		if (stringValue != null) {
		    try {
		        Long longValue = Long.parseLong(stringValue);
		        IDataUtil.put(cursor, "longValue", longValue);
		    } catch (NumberFormatException e) {
		        IDataUtil.put(cursor, "error", "Invalid number format: " + e.getMessage());
		    }
		}
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

